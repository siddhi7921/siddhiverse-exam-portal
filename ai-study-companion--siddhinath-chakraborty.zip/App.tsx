
import React, { useState, useEffect, useRef } from 'react';
import { FeatureType, Language, StudyMaterial, GeneratedContent, MockTest } from './types';
import { generateStudyContent, generateInteractiveMockTest } from './services/geminiService';
import Celebration from './components/Celebration';
import PaymentModal from './components/PaymentModal';

// Placeholder URL - You can replace this string with your image base64 or local path
const APP_ICON_URL = "https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100&h=100&fit=crop";

const App: React.FC = () => {
  const [showCelebration, setShowCelebration] = useState(true);
  const [showPayment, setShowPayment] = useState(false);
  const [examGoal, setExamGoal] = useState('GATE');
  const [language, setLanguage] = useState<Language>(Language.ENGLISH);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [results, setResults] = useState<GeneratedContent[]>([]);
  const [activeTab, setActiveTab] = useState<FeatureType>(FeatureType.IMPORTANT_QUESTIONS);
  const [mockTest, setMockTest] = useState<MockTest | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState<number | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const readFileAsBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve(base64String);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const processMaterial = async () => {
    if (!selectedFile) return;
    setIsProcessing(true);
    setResults([]);
    setMockTest(null);
    setScore(null);
    setCurrentQuestionIndex(0);

    try {
      const base64Data = await readFileAsBase64(selectedFile);
      const mimeType = selectedFile.type || 'application/pdf';

      if (activeTab === FeatureType.MOCK_TEST) {
        const test = await generateInteractiveMockTest(base64Data, mimeType, language, examGoal);
        setMockTest(test);
      } else {
        const content = await generateStudyContent(base64Data, mimeType, activeTab, language, examGoal);
        const newResult: GeneratedContent = {
          id: Date.now().toString(),
          title: `${activeTab} - ${selectedFile.name}`,
          content,
          type: activeTab,
          language
        };
        setResults([newResult]);
      }
    } catch (error) {
      console.error("Error processing material:", error);
      alert("Failed to process study material. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleMockAnswer = (optionIndex: number) => {
    if (!mockTest) return;
    const isCorrect = optionIndex === mockTest.questions[currentQuestionIndex].correctAnswer;
    
    if (currentQuestionIndex < mockTest.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      if (isCorrect) setScore(prev => (prev || 0) + 1);
    } else {
      const finalScore = (score || 0) + (isCorrect ? 1 : 0);
      setScore(finalScore);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {showCelebration && <Celebration onComplete={() => setShowCelebration(false)} />}
      <PaymentModal isOpen={showPayment} onClose={() => setShowPayment(false)} />

      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative group">
               <div className="absolute -inset-0.5 bg-gradient-to-r from-yellow-400 to-amber-500 rounded-full blur opacity-30 group-hover:opacity-60 transition duration-1000 group-hover:duration-200"></div>
               <img 
                 src={APP_ICON_URL} 
                 alt="App Icon" 
                 className="relative w-10 h-10 rounded-full border-2 border-white shadow-sm object-cover"
               />
               <span className="absolute -top-1 -right-1 bg-indigo-600 text-white text-[8px] px-1 rounded-full font-bold uppercase">Pro</span>
            </div>
            <div>
              <h1 className="text-lg font-bold font-poppins text-indigo-900 hidden sm:block leading-none">Exam Pro</h1>
              <p className="text-[10px] text-slate-400 font-medium hidden sm:block">by Siddhinath Chakraborty</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <select 
              value={language}
              onChange={(e) => setLanguage(e.target.value as Language)}
              className="bg-slate-100 border-none rounded-lg px-3 py-1.5 text-sm font-medium focus:ring-2 focus:ring-indigo-500"
            >
              <option value={Language.ENGLISH}>English</option>
              <option value={Language.HINDI}>Hindi</option>
              <option value={Language.BENGALI}>Bengali</option>
            </select>
            <button 
              onClick={() => setShowPayment(true)}
              className="bg-indigo-600 text-white px-4 py-1.5 rounded-lg text-sm font-bold hover:bg-indigo-700 transition-all shadow-md shadow-indigo-100"
            >
              Go Pro 🔥
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-4 lg:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sidebar Controls */}
        <aside className="lg:col-span-4 space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
              <i className="fas fa-bullseye text-indigo-600"></i> Exam Target
            </h2>
            <div className="grid grid-cols-2 gap-2 mb-6">
              {['GATE', 'CAT', 'CU', 'WBSU', 'CBSE', 'JEE'].map(exam => (
                <button
                  key={exam}
                  onClick={() => setExamGoal(exam)}
                  className={`py-2 px-3 rounded-xl text-sm font-semibold transition-all ${
                    examGoal === exam 
                      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' 
                      : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-100'
                  }`}
                >
                  {exam}
                </button>
              ))}
            </div>

            <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
              <i className="fas fa-file-upload text-indigo-600"></i> Upload Notes/PYQs
            </h2>
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-200 rounded-2xl p-8 text-center cursor-pointer hover:border-indigo-400 hover:bg-indigo-50/30 transition-all group"
            >
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileUpload} 
                className="hidden" 
                accept=".pdf,.txt,.jpg,.jpeg,.png"
              />
              <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                <i className="fas fa-cloud-upload-alt text-indigo-500 text-xl"></i>
              </div>
              <p className="text-sm font-medium text-slate-900">{selectedFile ? selectedFile.name : 'Click to upload PDF/Notes'}</p>
              <p className="text-xs text-slate-400 mt-1">Supports PDF, TXT, Images</p>
            </div>

            <div className="mt-6 flex flex-col gap-2">
              <label className="text-sm font-bold text-slate-700">Action Mode</label>
              {[
                { type: FeatureType.IMPORTANT_QUESTIONS, icon: 'fa-star' },
                { type: FeatureType.EXAM_ANSWERS, icon: 'fa-file-alt' },
                { type: FeatureType.MOCK_TEST, icon: 'fa-vial' }
              ].map(item => (
                <button
                  key={item.type}
                  onClick={() => setActiveTab(item.type)}
                  className={`flex items-center gap-3 w-full p-3 rounded-xl transition-all ${
                    activeTab === item.type 
                      ? 'bg-indigo-50 text-indigo-700 border-indigo-200 border shadow-sm' 
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <i className={`fas ${item.icon}`}></i>
                  <span className="font-semibold text-sm">{item.type}</span>
                </button>
              ))}
            </div>

            <button
              onClick={processMaterial}
              disabled={!selectedFile || isProcessing}
              className={`w-full mt-6 py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${
                !selectedFile || isProcessing 
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
                  : 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-lg hover:shadow-indigo-200 scale-100 active:scale-95'
              }`}
            >
              {isProcessing ? (
                <>
                  <i className="fas fa-circle-notch animate-spin"></i>
                  Processing...
                </>
              ) : (
                <>
                  <i className="fas fa-magic"></i>
                  Generate Insights
                </>
              )}
            </button>
          </div>

          <div className="bg-gradient-to-br from-indigo-900 to-violet-900 p-6 rounded-2xl text-white shadow-xl shadow-indigo-100 relative overflow-hidden">
             <div className="relative z-10">
               <h3 className="font-bold text-lg mb-2">Long-Context Reasoning</h3>
               <p className="text-sm opacity-80 mb-4">Our AI analyzes up to 200 pages of notes simultaneously for deep exam pattern recognition.</p>
               <div className="flex -space-x-2">
                 {[1,2,3,4].map(i => (
                   <img key={i} className="w-8 h-8 rounded-full border-2 border-indigo-800" src={`https://picsum.photos/seed/${i}/100/100`} alt="user" />
                 ))}
                 <span className="w-8 h-8 rounded-full bg-indigo-500 border-2 border-indigo-800 flex items-center justify-center text-[10px] font-bold">+2k</span>
               </div>
             </div>
             <div className="absolute top-0 right-0 p-4 opacity-10 text-6xl rotate-12">🧠</div>
          </div>
        </aside>

        {/* Content Display */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          {isProcessing && (
             <div className="bg-white rounded-2xl p-12 border border-slate-200 flex flex-col items-center justify-center text-center animate-pulse">
                <div className="w-20 h-20 bg-indigo-50 rounded-full flex items-center justify-center mb-6">
                  <i className="fas fa-brain text-4xl text-indigo-500 animate-bounce"></i>
                </div>
                <h2 className="text-xl font-bold text-slate-900 mb-2">Gemini is analyzing your material...</h2>
                <p className="text-slate-500 max-w-sm">Comparing notes with previous year trends for {examGoal} in {language}.</p>
             </div>
          )}

          {!isProcessing && results.length === 0 && !mockTest && (
            <div className="bg-white rounded-2xl p-12 border border-slate-200 text-center flex flex-col items-center">
              <img src="https://picsum.photos/seed/exam/400/300" className="rounded-2xl mb-8 opacity-90 shadow-lg w-full max-w-md object-cover" alt="Banner" />
              <h2 className="text-2xl font-bold text-slate-900 font-poppins mb-3">Your Journey to Success Starts Here</h2>
              <p className="text-slate-500 mb-8 max-w-lg">Upload your college notes or previous year papers to get instant, chapter-wise important questions and model answers.</p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full">
                <div className="p-4 bg-blue-50 rounded-xl border border-blue-100">
                  <i className="fas fa-language text-blue-600 mb-2 text-xl"></i>
                  <h4 className="font-bold text-sm text-blue-900">Multilingual</h4>
                  <p className="text-xs text-blue-700">English, Bengali, Hindi</p>
                </div>
                <div className="p-4 bg-green-50 rounded-xl border border-green-100">
                  <i className="fas fa-microscope text-green-600 mb-2 text-xl"></i>
                  <h4 className="font-bold text-sm text-green-900">Precision</h4>
                  <p className="text-xs text-green-700">Exam-oriented Logic</p>
                </div>
                <div className="p-4 bg-orange-50 rounded-xl border border-orange-100">
                  <i className="fas fa-bolt text-orange-600 mb-2 text-xl"></i>
                  <h4 className="font-bold text-sm text-orange-900">Fast</h4>
                  <p className="text-xs text-orange-700">Seconds to Insight</p>
                </div>
              </div>
            </div>
          )}

          {mockTest && score === null && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
               <div className="bg-indigo-600 p-6 text-white flex justify-between items-center">
                  <h2 className="text-xl font-bold font-poppins">{mockTest.title}</h2>
                  <span className="bg-indigo-500 px-3 py-1 rounded-full text-sm font-bold">
                    Q {currentQuestionIndex + 1} / {mockTest.questions.length}
                  </span>
               </div>
               <div className="p-8">
                  <h3 className="text-lg font-semibold text-slate-900 mb-6 leading-relaxed">
                    {mockTest.questions[currentQuestionIndex].question}
                  </h3>
                  <div className="space-y-3">
                    {mockTest.questions[currentQuestionIndex].options.map((opt, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleMockAnswer(idx)}
                        className="w-full text-left p-4 rounded-xl border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50 transition-all font-medium flex items-center gap-3"
                      >
                        <span className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-500">{String.fromCharCode(65 + idx)}</span>
                        {opt}
                      </button>
                    ))}
                  </div>
               </div>
            </div>
          )}

          {score !== null && mockTest && (
            <div className="bg-white rounded-2xl p-12 border border-slate-200 text-center animate-in zoom-in duration-500">
              <div className="text-6xl mb-4">🏆</div>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Test Complete!</h2>
              <p className="text-slate-500 mb-8">You scored {score} out of {mockTest.questions.length}</p>
              
              <div className="inline-flex items-center justify-center w-32 h-32 rounded-full border-8 border-indigo-500 text-3xl font-bold text-indigo-600 mb-8">
                {Math.round((score / mockTest.questions.length) * 100)}%
              </div>

              <div className="flex gap-4 justify-center">
                <button 
                  onClick={() => { setMockTest(null); setScore(null); }}
                  className="px-6 py-2 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
                >
                  Back to Tools
                </button>
                <button 
                  onClick={processMaterial}
                  className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
                >
                  Retry Test
                </button>
              </div>
            </div>
          )}

          {results.map(res => (
            <div key={res.id} className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="bg-slate-50 border-b border-slate-200 p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">{res.type}</span>
                  <h2 className="font-bold text-slate-900 text-sm md:text-base truncate max-w-[200px]">{res.title}</h2>
                </div>
                <div className="flex gap-2">
                  <button className="p-2 hover:bg-slate-200 rounded-lg text-slate-500 transition-colors" title="Download">
                    <i className="fas fa-download"></i>
                  </button>
                  <button className="p-2 hover:bg-slate-200 rounded-lg text-slate-500 transition-colors" title="Print">
                    <i className="fas fa-print"></i>
                  </button>
                </div>
              </div>
              <div className="p-6 md:p-8">
                <div className="prose max-w-none prose-indigo prose-headings:font-poppins prose-headings:text-indigo-900 whitespace-pre-wrap text-slate-700 leading-relaxed">
                  {res.content}
                </div>
              </div>
              <div className="bg-indigo-50/50 p-4 border-t border-slate-100 flex items-center gap-2">
                <i className="fas fa-info-circle text-indigo-400"></i>
                <p className="text-xs text-indigo-600 font-medium">This content was generated by Gemini 3 Pro reasoning over your specific materials.</p>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Persistent CTA */}
      <div className="fixed bottom-6 right-6 z-40">
        <button 
          onClick={() => setShowPayment(true)}
          className="flex items-center gap-3 px-6 py-4 bg-indigo-600 text-white rounded-full shadow-2xl hover:bg-indigo-700 hover:scale-105 transition-all group"
        >
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center group-hover:animate-spin">
            <i className="fas fa-graduation-cap"></i>
          </div>
          <span className="font-bold">Unlock Success</span>
        </button>
      </div>

      <footer className="bg-white border-t border-slate-200 py-10 text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col items-center">
          <div className="flex items-center gap-3 mb-4">
             <img 
               src={APP_ICON_URL} 
               alt="Developer" 
               className="w-12 h-12 rounded-full border-2 border-indigo-100 p-0.5 object-cover grayscale hover:grayscale-0 transition-all cursor-pointer"
             />
             <div className="text-left">
               <p className="text-slate-800 font-bold text-sm">siddhinath chakraborty</p>
               <p className="text-indigo-600 text-xs font-semibold">RCCIIT Student </p>
             </div>
          </div>
          <p className="text-slate-400 text-xs">© 2026 AI Study Comaprison rights.</p>
          <div className="mt-4 inline-block bg-yellow-50 border border-yellow-100 rounded-full px-6 py-2">
            <p className="text-xs font-bold text-yellow-800">
              Support Creator: <span className="text-indigo-700">7586089492</span> (GPay/PhonePe)
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
