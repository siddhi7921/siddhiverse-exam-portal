
export enum Language {
  ENGLISH = 'English',
  HINDI = 'Hindi',
  BENGALI = 'Bengali'
}

export enum FeatureType {
  IMPORTANT_QUESTIONS = 'Important Questions',
  EXAM_ANSWERS = 'Exam Answers',
  MOCK_TEST = 'Mock Test',
  EVALUATION = 'Evaluation'
}

export interface StudyMaterial {
  id: string;
  name: string;
  type: string;
  content: string; // Base64 for PDF or text content
  mimeType: string;
}

export interface GeneratedContent {
  id: string;
  title: string;
  content: string;
  type: FeatureType;
  language: Language;
}

export interface MockQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface MockTest {
  id: string;
  title: string;
  questions: MockQuestion[];
}
