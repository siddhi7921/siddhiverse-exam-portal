
import React, { useEffect, useState } from 'react';

const Celebration: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [visible, setVisible] = useState(true);
  const APP_ICON_URL = "https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100&h=100&fit=crop";

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
      onComplete();
    }, 3500);
    return () => clearTimeout(timer);
  }, [onComplete]);

  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-white overflow-hidden">
      <div className="relative mb-8">
        <div className="absolute -inset-4 bg-indigo-500/20 rounded-full animate-ping"></div>
        <img 
          src={APP_ICON_URL} 
          alt="Icon" 
          className="relative w-24 h-24 rounded-full border-4 border-indigo-600 shadow-xl object-cover animate-bounce"
        />
        <div className="absolute -bottom-2 -right-2 bg-indigo-600 text-white text-[10px] px-2 py-0.5 rounded-full font-bold shadow-lg">PRO 🥇</div>
      </div>
      
      <h1 className="text-4xl font-bold text-indigo-900 font-poppins animate-pulse text-center px-4">
        Exam Companion
      </h1>
      <p className="mt-2 text-indigo-600 font-semibold tracking-widest text-xs uppercase">by Siddhinath Chakraborty</p>
      
      <div className="flex gap-4 mt-12">
        {['📚', '📝', '🎓', '⚡'].map((emoji, idx) => (
          <span key={idx} className="text-5xl animate-float" style={{ animationDelay: `${idx * 0.2}s` }}>
            {emoji}
          </span>
        ))}
      </div>
      
      <div className="absolute top-1/4 left-1/4 text-4xl animate-ping opacity-50">✨</div>
      <div className="absolute bottom-1/4 right-1/4 text-4xl animate-ping opacity-50">🎉</div>
      <div className="absolute top-1/3 right-1/4 text-4xl animate-bounce opacity-50">🔥</div>
      
      <div className="absolute bottom-10 left-0 right-0 text-center animate-in slide-in-from-bottom duration-1000">
        <p className="text-slate-400 text-[10px] font-medium uppercase tracking-[0.2em]">Preparing Excellence...</p>
      </div>
    </div>
  );
};

export default Celebration;
