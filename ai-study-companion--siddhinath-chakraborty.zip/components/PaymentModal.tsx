
import React from 'react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in duration-300">
        <div className="bg-indigo-600 p-6 text-white text-center">
          <h2 className="text-2xl font-bold font-poppins">Upgrade to Pro 🥇</h2>
          <p className="opacity-90">Unlock unlimited scans and advanced reasoning.</p>
        </div>
        
        <div className="p-8">
          <div className="space-y-4 mb-8">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                <i className="fas fa-check"></i>
              </div>
              <span>Unlimited PDF Analysis</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                <i className="fas fa-check"></i>
              </div>
              <span>Multi-language Tutor (Hindi/Bengali)</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                <i className="fas fa-check"></i>
              </div>
              <span>Full Length Mock Tests</span>
            </div>
          </div>

          <div className="bg-indigo-50 rounded-xl p-4 mb-6 border border-indigo-100">
            <p className="text-sm text-indigo-700 font-semibold mb-1">Pricing Options:</p>
            <div className="flex justify-between items-center text-lg font-bold text-indigo-900">
              <span>Standard</span>
              <span>₹99 / mo</span>
            </div>
            <div className="flex justify-between items-center text-lg font-bold text-indigo-900">
              <span>Premium</span>
              <span>₹299 / mo</span>
            </div>
          </div>

          <div className="text-center p-4 bg-yellow-50 border border-yellow-200 rounded-xl mb-6">
            <p className="text-xs text-yellow-700 font-medium uppercase tracking-wider mb-2">How to Pay</p>
            <p className="text-xl font-bold text-yellow-900">7586089492</p>
            <p className="text-sm text-yellow-700 mt-1">Send payment via GPay/PhonePe/Paytm</p>
          </div>

          <button 
            onClick={onClose}
            className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200"
          >
            I've Paid - Let's Go!
          </button>
          
          <p className="text-center text-gray-400 text-xs mt-4">
            After payment, your account will be upgraded within 2 hours.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;
