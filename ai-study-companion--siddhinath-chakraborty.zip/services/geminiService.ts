
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { Language, FeatureType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateStudyContent = async (
  material: string,
  mimeType: string,
  type: FeatureType,
  language: Language,
  examGoal: string
): Promise<string> => {
  const model = 'gemini-3-pro-preview';
  
  let prompt = "";
  switch (type) {
    case FeatureType.IMPORTANT_QUESTIONS:
      prompt = `Act as an expert examiner for ${examGoal} exams in India. 
      Analyze the attached study material and generate a list of chapter-wise IMPORTANT questions.
      Ensure the difficulty level matches ${examGoal} standards.
      Output the content in ${language}. Use clear formatting with headings.`;
      break;
    case FeatureType.EXAM_ANSWERS:
      prompt = `Act as a top-tier tutor for ${examGoal} exams. 
      Analyze the attached material and provide comprehensive, exam-oriented answers to the most likely questions.
      Focus on structure: Introduction, Body (Bullet points), and Conclusion.
      Output in ${language}.`;
      break;
    case FeatureType.MOCK_TEST:
      prompt = `Generate a full Mock Test based on the attached material for ${examGoal}.
      Provide a mix of Multiple Choice Questions (MCQs) and descriptive questions if applicable.
      Output in ${language}. Focus on high-probability topics.`;
      break;
  }

  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        { inlineData: { data: material, mimeType } },
        { text: prompt }
      ]
    },
    config: {
      temperature: 0.7,
      thinkingConfig: { thinkingBudget: 8000 }
    }
  });

  return response.text || "Failed to generate content.";
};

export const generateInteractiveMockTest = async (
  material: string,
  mimeType: string,
  language: Language,
  examGoal: string
): Promise<any> => {
  const model = 'gemini-3-pro-preview';

  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        { inlineData: { data: material, mimeType } },
        { text: `Generate a structured JSON mock test for ${examGoal} based on the material. 
        Output 5 high-quality MCQs. Response must be in ${language}.` }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          questions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctAnswer: { type: Type.INTEGER, description: "Index of correct option (0-3)" },
                explanation: { type: Type.STRING }
              },
              required: ["question", "options", "correctAnswer", "explanation"]
            }
          }
        },
        required: ["title", "questions"]
      }
    }
  });

  return JSON.parse(response.text);
};
